package com.jar.service;


import java.util.List;

import com.jar.domain.BoardVO;


public interface BoardService {
	
	public void register(BoardVO board);  // 새 글을 등록할 때 사용하는 메소드
	
	public BoardVO get(Long bno); // 내가 지정한 글 번호를 이용해서 레코드 꺼내올 때

	public boolean modify(BoardVO board); // 기존 글을 수정할 때 
	
	public boolean remove(Long bno); // 내가 지정한 글 번호 이용하여 해당 글 삭제할 때  
	
	public List<BoardVO> getList();  // 전체 데이터 조회할 때
	
	

	
	
}
