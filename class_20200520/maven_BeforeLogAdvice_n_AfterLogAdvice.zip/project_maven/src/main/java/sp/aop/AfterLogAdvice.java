package sp.aop;

import java.lang.reflect.Method;
import org.springframework.aop.AfterReturningAdvice;


public class AfterLogAdvice implements AfterReturningAdvice {

   @Override
   public void afterReturning(Object returnValue, Method method, Object[] args, Object target) throws Throwable {
      /*
       * 1. 추가된 객체
       * 2.핵심클래스의 method명
       * 3.생성된 객체들
       * 4.targetClass의 객체
       */
      System.out.println(method.toString()+"method:"+target+"에서 호출 후!");

   }

}