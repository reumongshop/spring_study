package sp.aop;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext; // xml문서를 찾을 수 있게 하는 lib

public class ResultMain {

   public static void main(String[] args) {
      String path="sp/aop/app.xml";
      ApplicationContext context = new ClassPathXmlApplicationContext(path);
      
      //TestService service= (TestService)context.getBean("testServiceImpl");
      //원래는 위의 것이 일반적이지만, AOP 객체를 얻어오기 위해서는, 밑에처럼 AOP객체를 얻는다.
      
      //AOP객체를 생성 -> Advisor 작동 -> Advice + pointcut 실행
      TestService service= (TestService)context.getBean("testServiceImpl");
      service.save("AOP 적용 연습");
      //before advice(before() 작동 실행) -> 실행상태에서 처리
      
      service.write();
      

   }

}