package sp.aop;

import java.lang.reflect.Method;
import org.springframework.aop.MethodBeforeAdvice;
// 이후라고하면 MethodAfterAdvice 구현받으면 된다.

//추가
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


// Advice : 모든 Class에 공통으로 사용할 기능 (소스코드 -> Method 중심)
// interface 대신 (OOP 방식)에 Advice Class를 작성해서 구현(AOP방식) -> ﻿Aspect Oriented Programming

// 실행 위치를 특정 Method의 앞에서 실행 -> MethodBeforeAdvice를 구현
public class BeforeLogAdvice implements MethodBeforeAdvice {
	
	private Log log = LogFactory.getLog(getClass()); // Log 객체를 얻어오는 문장
			
	// 1) Spring 의 AOP(Method 중심) -> 핵심 Class의 Method
	// 2) 생성된 객체를 배열로 받아온다
	// 3) target Class (핵심 Class의 객체를 얻어온다)0

	@Override
	public void before(Method method, Object[] args, Object target) throws Throwable {
		// TODO Auto-generated method stub
		
		log.info(method.toString() + "Method : " + target + "에서 호출 전!");

	}

}
