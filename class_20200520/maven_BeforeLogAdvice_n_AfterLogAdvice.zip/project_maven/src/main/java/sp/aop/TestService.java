package sp.aop;

// 모든 핵심 Class에서 공통으로 사용할 목적으로의 Method 작성
public interface TestService {
	
	public void save(String msg); // 입력
	public void write(); // 출력

}
