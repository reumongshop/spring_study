package sp.aop;

public class TestServiceImpl implements TestService {

	   private String msg = "before AOP 연습"; // save() Method 앞에 호출하라고 명령할 것임(Advice)
	   @Override
	   public void save(String msg) { // 회원 수정
	      // TODO Auto-generated method stub
	      this.msg=msg;
	      System.out.println("save() Method 호출");   // 코딩 양이 줄어들음 -> compile 빨라짐 -> 손이 덜 가서 오타 줄어들음
	   }//save() END

	   
	   @Override
	   public void write() {
	      // TODO Auto-generated method stub
	      System.out.println("write method 호출 : "+this.msg);
	   }//write() END

	   
	}//TestServiceImpl CLASS END